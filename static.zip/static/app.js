(() => {
  const menuButton = document.querySelector('[data-menu-toggle]');
  const menu = document.querySelector('[data-menu]');
  if (menuButton && menu) {
    menuButton.addEventListener('click', () => {
      const open = menu.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(open));
    });
    menu.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => menu.classList.remove('open')));
  }
  const search = document.querySelector('[data-product-search]');
  const category = document.querySelector('[data-category-filter]');
  const cards = [...document.querySelectorAll('[data-product-grid] .product-card')];
  const filter = () => {
    const q = (search?.value || '').trim().toLocaleLowerCase('vi');
    const c = category?.value || '';
    cards.forEach((card) => {
      const text = (card.dataset.title || '').toLocaleLowerCase('vi');
      const matchesQuery = !q || text.includes(q);
      const matchesCategory = !c || card.dataset.category === c;
      card.hidden = !(matchesQuery && matchesCategory);
    });
  };
  search?.addEventListener('input', filter);
  category?.addEventListener('change', filter);
})();
